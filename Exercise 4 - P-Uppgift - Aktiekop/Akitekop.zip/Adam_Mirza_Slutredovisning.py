# Titel: Akiteköp
# Författare: Adam Mirza
# Datum: 2018-01-28
#
# Det här är ett program för hantering av akitevärden och använda akitevärderna för diversa analyser
#
# Programmet ger användaren alternativet att utföra fundamental och teknisk analys på tre akiter
# samt rangordnar akiterna med avseende på dess betavärde

# -------------------------------------- importering av allmäna system moduler ------------------------------------- #
""" Anledningen till att vi importerar datetime och dateutil.relativedelta är för att kunna förhålla
    vår programkod till dom datumen värderna hos akiterna förhåller sig till. Därefter importerar vi med hjälp
    av modulerna in datum/värderna hos alla tre aktier i dom matematiska uträkningarna för att beräkna betavärde,
    fundamenetalanalysen samt den tekniska analysen """

import datetime
import dateutil.relativedelta

# ------------------------------------ Objektskapande för hela programmet ------------------------------------------ #

# class (model) av Fundamenta som får sina värden från fundamenta.txt-filen
# privata variabler som endast kan nås via get-metoderna


class Fundamenta:
    __name = None       # '''Vi skriver objektet __name = None för att hänvisa att name avsaknar ett värde för stunden när vi användaer klassen Fundamenta i vald kodsnutt'''
    __soliditet = 0     # '''objektet _soliditet har värdet noll nät vi inporterar klassen Fundamenta i vald kodsnnutt'''
    __petal = None      # '''Vi skriver objektet __petal = None för att hänvisa att name avsaknar ett värde för stunden när vi användaer klassen Fundamenta i vald kodsnutt'''
    __pstal = 0         # '''objektet _pstal har värdet noll nät vi inporterar klassen Fundamenta i vald kodsnnutt''

    '''Genom att ange __name som None kategoriesrar jag variabeln oberoende för stunden'''


    def __init__(self, name, soliditet, petal, pstal):   #__init__ är en definition som anger typ att varje gång vi gör/använder en av dessa saker, se till att du kör följande kod också".
                                                        # VIlket är objektnamnen namn, soliditet, petal och pstal som kör följande efter = tecknet. Self är en referens till dom objekten vi har skapat, dvs ex self.__name
        self.__name = name
        self.__soliditet = soliditet
        self.__petal = petal
        self.__pstal = pstal

    ''' Här vill vi sedan ange self.__objektnamnet som return för att sedan använda objektet i våra kommande metodsatser. 
        När vi vill hämta objekten och ange dom i diversa metodsatser vill vi ange dom inuti en klass i syfte av importering i 
        exemepelvis andra framtida python koder.'''

    def get_name(self):
        return self.__name   #Vi skapar funktioner för att snabbare kunna returera våra värdeobjekt till nästkommande funktioner och/eller klasser

    def get_soliditet(self):
        return self.__soliditet #Vi skapar funktioner för att snabbare kunna returera våra värdeobjekt till nästkommande funktioner och/eller klasser

    def get_petal(self):
        return self.__petal     #Vi skapar funktioner för att snabbare kunna returera våra värdeobjekt till nästkommande funktioner och/eller klasser

    def get_pstal(self):
        return self.__pstal     #Vi skapar funktioner för att snabbare kunna returera våra värdeobjekt till nästkommande funktioner och/eller klasser

    def toString(self):
        return self.get_name(), self.get_soliditet(), self.get_petal(), self.get_pstal()    #Vi skapar funktioner för att snabbare kunna returera våra värdeobjekt till nästkommande funktioner och/eller klasser

'''Här komprimerar vi samtliga till en enda funktion så att vi kan importera self.objektet i en enda sträng/def funktion'''

# class (model) av Kurser som får sina värden från kurser.txt-filen
# privata variabler som endast kan nås via get-metoderna

class Kurser:
    '''Först anger vi objekten som none (dvs inga värden som objektet ska förhålla sig till'''
    __name = None       #Som variabeln __name
    __date = 0          #Vi anger vår värdevariabeln __date som 0 istället för none eftersom det är ett int/siffervärde
    __value = 0         # Vi anger vår värdevariabeln __value som 0 istället för none eftersom det är ett int/siffervärde

    def __init__(self, name, date, value):
        self.__name = name      #Vi säger att __name ska initieras när variabelnamnet name infogas i kommande metoder
        self.__date = date      #Vi säger att __date ska initieras när variabelnamnet date infogas i kommande metoder
        self.__value = value    #Vi säger att __value ska initieras när variabelnamnet value infogas i kommande metoder

    def get_name(self):
        return self.__name      #Vi skapar en funktion som säger att objektet self.__name kan retureras i andra/kommande metoder

    def get_date(self):
        return self.__date      #Vi skapar en funktion som säger att objektet self.__date kan retureras i andra/kommande metoder

    def get_value(self):
        return self.__value     #Vi skapar en funktion som säger att objektet self.__value kan retureras i andra/kommande metoder

    def toString(self):
        return self.get_name(), self.get_date(), self.get_value()
        # Vi skapar en klass som ska ge samtliga objekterna möjlighet att använda i nästkommande programkod i en def funktion


# class (model) av Omx som får sina värden från omx.txt-filen
# privata variabler som endast kan nås via get-metoderna

class Omx:
    __date = 0
    __value = 0

    def __init__(self, date, value):
        self.__date = date
        self.__value = value

    def get_date(self):
        return self.__date

    def get_value(self):
        return self.__value


# ------ Klass som ska bestämma och beräkna avkastningstidsperioden med mera på fundamental och teknisk analys ------ #

# Denna metod hittar högsta värdet de senaste 30 dagarna
# Tar namn på aktien man vill jämföra samt listan på alla kurser som är tagen från kurser.txt filen som inparametrar
# tar sista datumet samt 1 månad tidigare och jämför lägsta värdet mellan dessa datum
# start_index är på vilket index i listan som dateMinusOneMonth ligger på i array_of_kurser listan
# stop_index är vilket index i listan som lastDate ligger på i array_of_kurser listan
# max_value sparar det största värdet mellan de två datumen och returnerar värdet


def highestPrice(arraylist_of_kurser, name):   # higestPrice ska beräkna det högsta värdet på våra aktielistor dom senaste 30 dagarna
    last_date = arraylist_of_kurser[arraylist_of_kurser.__len__() - 1].get_date()
    #Hittar det senaste datumet i 30 dagars intervallet, genom att förhålla till listan - den sista datumet. Därefter hämtas det sista datumet
    one_month_earlier = datetime.datetime.strptime(last_date, "%y-%m-%d")
    #Gör så att vi kan läsa av listan genom att ange referensen Y/M/D och därefter hitta det första datumet på en av dom 30 dagarna vi ska förhålla oss till

    dateMinusOneMonth = one_month_earlier - dateutil.relativedelta.relativedelta(months=1)
    #Funktionen gör så att vi finner det sista datumet på månaden. Genom att ta månadsperioden minus den sista dagen på månaden

    start_index = 0
    stop_index = 0

    for i in range(len(arraylist_of_kurser)):
        if arraylist_of_kurser[i].get_name() == name:   #Listan på det utvalda kursvärdet är = objektnamnet name
            if arraylist_of_kurser[i].get_date() == dateMinusOneMonth.strftime('%y-%m-%d'): #Om värdet är dateMinusOneMonth
                start_index = i  #Ange att indexet i listan dateMinusOneMonth ligger på plats i inuti array_of_kurser listen
            if arraylist_of_kurser[i].get_date() == last_date:   #Annars om värdet är lastDate
                stop_index = i   #Ange att indexet i listan lastDate ligger på plats i inuti array_of_kurser listen
                max_value = arraylist_of_kurser[i].get_value() #Hänvisar att maxvärdet är variabeln till högerledet
    for i in range(start_index, stop_index):    #Vi ska förhålla metoderna nedan till start och stop indexvärderna i
        if arraylist_of_kurser[i].get_value() > max_value:
            max_value = arraylist_of_kurser[i].get_value()
            # Max värdet ska endast vara lika med arraylist_of_kurser
            #(som förhåller sig till indexvärdet i vilket är det värdet vi söker) om det fundna värdet är mindre än maxvärdet
    return max_value #returnerna max_value


# Följande funktion gör samma som ovan, fast hittar minsta värdet istället för högsta
def lowestPrice(arraylist_of_kurser, name):# lowestPrice ska beräkna det lägsta värdet på våra aktielistor dom senaste 30 dagarna
    last_date = arraylist_of_kurser[arraylist_of_kurser.__len__() - 1].get_date()
    # Hittar det senaste datumet i 30 dagars intervallet, genom att få vår nuvarande lista att analyseras. Därefter hitta och hämta det sista datumet.
    one_month_earlier = datetime.datetime.strptime(last_date, "%y-%m-%d")
    # Gör så att vi kan läsa av listan genom att ange referensen Y/M/D och därefter hitta det första datumet på en av dom 30 dagarna vi ska förhålla oss till

    dateMinusOneMonth = one_month_earlier - dateutil.relativedelta.relativedelta(months=1)
    # Strängen gör så att vi finner det sista datumet på månaden. Genom att ta månadsperioden minus en dag

    start_index = 0
    stop_index = 0

    for i in range(len(arraylist_of_kurser)):
        if arraylist_of_kurser[i].get_name() == name:   #Listan på det utvalda kursvärdet är = objektnamnet name
            if arraylist_of_kurser[i].get_date() == dateMinusOneMonth.strftime('%y-%m-%d'): #Om värdet är dateMinusOneMonth
                start_index = i #Ange att indexet i listan dateMinusOneMonth ligger på plats i inuti array_of_kurser listen
            if arraylist_of_kurser[i].get_date() == last_date:   #Annars om värdet är lastDate
                stop_index = i  #Ange att indexet i listan lastDate ligger på plats i inuti array_of_kurser listen
                mini_value = arraylist_of_kurser[i].get_value()  #Hänvisar att minimumvärdet är variabeln till högerledet
    for i in range(start_index, stop_index):    #Vi ska förhålla metoderna nedan till start och stop indexvärderna i
        if arraylist_of_kurser[i].get_value() < mini_value:
            mini_value = arraylist_of_kurser[i].get_value()
            # Minsta värdet ska endast vara lika med arraylist_of_kurser
            #(som förhåller sig till indexvärdet i vilket är det värdet vi söker) om det fundna värdet är större än minimumvärdet
    return mini_value #returnerna min_value


#   Funktionen delar på värdet det senaste datumet genom värdet en månad tidigare och returnerar värdet
#   Tar namn på aktien detta gäller och lista på kurser som inparametrar.
def movementLastMonth(arraylist_of_kurser, name): #Vi använder listan av kursvärderna och namnen på aktierna
    last_date = arraylist_of_kurser[arraylist_of_kurser.__len__() - 1].get_date()
    # Hittar det senaste datumet i 30 dagars intervallet, genom att få vår nuvarande lista att analyseras. Därefter hitta och hämta det sista datumet.
    one_month_earlier = datetime.datetime.strptime(last_date, "%y-%m-%d")
    # Gör så att vi kan läsa av listan genom att ange referensen Y/M/D och därefter hitta det första datumet på en av dom 30 dagarna vi ska förhålla oss till
    dateMinusOneMonth = one_month_earlier - dateutil.relativedelta.relativedelta(months=1)
    # Strängen gör så att vi finner det sista datumet på den tidigare månaden. Genom att ta månadsperioden minus en dag

    value_dateminusonemonth = 0 #Sätter variabeln på noll för tillfället
    value_last_date = 0         #Sätter variabeln på noll för tillfället

    # För att se om detta stämmer kan du skriva print(lastDate, " onemonth",one_month_eralier, " dateminus", dateMinusOneMonth)
    for i in range(0, len(arraylist_of_kurser)):
        if arraylist_of_kurser[i].get_name() == name:
        #Här hämtar vi namnet på aktien innan vi hämtar värdet
            if arraylist_of_kurser[i].get_date() == dateMinusOneMonth.strftime('%y-%m-%d'):
                value_dateminusonemonth = arraylist_of_kurser[i].get_value()
                # För att se om detta stämmer kan du skriva print(value_dateminusonemonth)
            if arraylist_of_kurser[i].get_date() == last_date:
            #Här hämtar vi vårt specifika datum och därefter hämtar vi dess aktievärde
                value_last_date = arraylist_of_kurser[i].get_value()
                # För att se om detta stämmer kan du skriva print(value_last_date)

    value_change = float(value_last_date) / float(value_dateminusonemonth)
    return value_change * 100

#   Tar lista på omx som inparameter
#   Delar värdet av det sista datumet med värdet en månad tidigare och returnerar det nya värdet i float.

def marketValuePeriod(arraylist_of_omx): #Vi använder oss av kursvärderna hos omx listen
    last_date = arraylist_of_omx[(arraylist_of_omx.__len__() - 1)].get_date()
    # Hittar det senaste datumet i 30 dagars intervallet, genom att få vår nuvarande lista att analyseras. Därefter hitta och hämta det sista datumet.
    one_month_earlier = datetime.datetime.strptime(''.join(last_date), "%y-%m-%d")
    # Gör så att vi kan läsa av listan genom att ange referensen Y/M/D och därefter hitta det första datumet på en av dom 30 dagarna vi ska förhålla oss till
    dateMinusOneMonth = one_month_earlier - dateutil.relativedelta.relativedelta(months=1)
    # Strängen gör så att vi finner det sista datumet på den tidigare månaden. Genom att ta månadsperioden minus en dag

    value_dateminusonemonth = 0 #Sätter variabeln på noll för tillfället
    value_last_date = 0         #Sätter variabeln på noll för tillfället

    for i in range(len(arraylist_of_omx)):
        # få sista datumet - 1 månad i samma format. Returnerna sista datumets värde / månaden innans värde
        if ''.join(arraylist_of_omx[i].get_date()) == dateMinusOneMonth.strftime('%y-%m-%d'):
            #Om '' kollaborerat (join) med arraylist_of_omx[i].get_date() är lika med högerledet
            value_dateminusonemonth = arraylist_of_omx[i].get_value()
        if arraylist_of_omx[i].get_date() == last_date:
            #Om endast det utplockade datumet från vänsterledet är lika med det senaste datumet på månaden (högerledet)
            value_last_date = arraylist_of_omx[i].get_value()
    return float(value_last_date) / float(value_dateminusonemonth)

# -------------------------------- Programkoden för Fundamentalanalysen --------------------------------------------- #

# Val 1, fundamentaAnalys som har en lista från fundamenta.txt som inparameter
# Låter dig välja mellan de valbara aktierna och skriver ut namn, soliditet, p/e-tal samt p/s-tal


def fundamentaAnalys(arraylist_of_fundamenta):
    print("En fundamental analys kan utföras på följande aktier:\n ")
    iVal = 1
    # Loopar igenom alla aktier som finns istället för att hårdkoda
    for i in range(0, len(arraylist_of_fundamenta)):
        print(" ".join(map(str, [iVal, arraylist_of_fundamenta[i].get_name()])))
        #Först så kollaborerar vi mha .join genom att ihopsätta någonting (" ") med allting som finns inuti paranteserna
        #Sedan så använder vi map genom att förhålla arraylist... strängen till vår "funktion" iVal vilket är en loop (iVal+=1)
        iVal += 1

    while True:
    #Medans allt detta är sant och förhållningsbart till våra strängar
        print("Vilken aktie vill du göra en fundamental analys på?\n")
        val = int(input())
        #Int forcerar att användaren ska förhålla sig till siffror som inmatning
        if val <= len(arraylist_of_fundamenta):
        #Om det infogade valet är mindre i värde i jämförelse med antal sifferalternativ hos fundamentalistan (linjesiffran)
        # visas informationen av fundamentalanalysen
        #Om användaren har skrivit in fel valalternativ så visas testen "fel val" och valaternativet börjar om
            print("-------- Fundamental analys pa " + arraylist_of_fundamenta[val - 1].get_name(), "--------")
            print("foretagets soliditet ar " + arraylist_of_fundamenta[val - 1].get_soliditet(), "%")
            print("foretagets p/e-tal ar " + arraylist_of_fundamenta[val - 1].get_petal())
            print("foretagets p/s- tal " + arraylist_of_fundamenta[val - 1].get_pstal() + " \n")
            break
        else:
            print("fel val")


# ---------------------------------- Programkoden för Tekniska analysen --------------------------------------------- #

#   Denna metod anropas när man valt nummer 2, teknisk analys.
#   Tar 3 listor som inparametrar. Dessa listor är från txt filerna
#   Loopar igenom alla aktier och skriver ut de först.

#   Sedan skriver den ut info. Ropar på 4 andra funktioner också
#   (movementLastMonth, marketValuePeriod,lowestPrice och highestPrice)
#   för att få värdena man söker för den valda aktien


def tekniskAnalys(arraylist_of_kurser, arraylist_of_omx, arraylist_of_fundamenta): #Vi använder oss av samtliga listor
    print("En teknisk analys kan utföras på följande aktier:\n")
    iVal = 1
    index = []
    for i in range(0, len(arraylist_of_kurser)):
    #Från noll till den sista linjesiffran
        if i != arraylist_of_kurser.__len__() - 1:
        #Om i är inte lika med listan i kurser.txt där listan kallas efter len minus värdet 1 av len uträkningen hos kurser.txt
            if arraylist_of_kurser[i].get_name() != arraylist_of_kurser[i + 1].get_name():
            # Om vänsterledet inte är lika med högerledet
                print(" ".join(map(str, [iVal, ''.join(arraylist_of_kurser[i].get_name())])))
                #Printa ut arraylist_of_kurser..... som ska kollaborera med nånting (" ") och
                #ska förhålla sig till "funktionen" (pga map) iVal vilket är en loop som är insatt i += 1 regelsatsen
                index.append(i)
                #kollaborera index listan med i varibeln, i är en varibel som är ett siffervärde
                iVal += 1
                #Skapad loop
        else:
        #Om i är lika med array_of_kurser.__len__() - 1
            print(" ".join(map(str, [iVal, ''.join(arraylist_of_kurser[i].get_name())])))
            # Printa ut arraylist_of_kurser..... som ska kollaborera med nånting (" ") och
            # ska förhålla sig till "funktionen" (pga map) iVal vilket är en loop som är insatt i += 1 regelsatsen
            index.append(i)
            # kollaborera index listan med i varibeln, i är en varibel som är ett siffervärde
            iVal += 1
            # Skapad loop

    while True:
    #Om allt detta är sant mellan linje 276 till 297 så fortsätt...
        print("Vilken aktie vill du göra en teknisk analys på?\n")
        val = int(input())
        if val <= iVal - 1:
            print("-------- Teknisk analys pa " + ', '.join(
                arraylist_of_kurser[index[val - 1]].get_name()) + "--------")
            print(" ".join(map(str, ["Kursutveckling senaste 30 dagarna ", movementLastMonth(arraylist_of_kurser,
                                                                                             arraylist_of_kurser[index[
                                                                                                 val - 1]].get_name()),
                                     "%"])))
            # loop för att få ut p/s tal i fundamenta
            for i in range(len(arraylist_of_fundamenta)):
                if arraylist_of_fundamenta[i].get_name() == ''.join(arraylist_of_kurser[index[val - 1]].get_name()):
                    pstal = arraylist_of_fundamenta[i].get_pstal()
            __beta_value = float(pstal) / marketValuePeriod(arraylist_of_omx)
            # loop för att få ut p/s tal i fundamenta
            print(" ".join(map(str, ["betavärde", __beta_value])))
            print(" ".join(map(str, ["Lägsta kurs senaste 30 dagarna ", lowestPrice(arraylist_of_kurser,
                                                                                    arraylist_of_kurser[
                                                                                        index[val - 1]].get_name())])))
            print(" ".join(map(str, ["Högsta kurs senaste 30 dagarna",
                                     highestPrice(arraylist_of_kurser, arraylist_of_kurser[index[val - 1]].get_name()),
                                     "\n"])))
            break
        else:
            print("fel val")

# ----------------------------- Rangordning av aktierna med avseende på deras värden -------------------------------- #

#   Rangordnar med högsta betavärdet först
#   Tar två listor som inparametrar, lista av kurser samt lista av fundamenta.txt filen
#   Har pstal som en lista av arrays. Varje array har två platser. Första är namnet andra är betavärdet.


def rangordning(arraylist_of_kurser, arraylist_of_fundamenta):
    print("—–Rangordning av aktier med avseende på dess betavärde—— \n")
    antal_aktier = 0
    index = []
    pstal = []

    for i in range(0, len(arraylist_of_kurser)):
        if i != arraylist_of_kurser.__len__() - 1:
            if arraylist_of_kurser[i].get_name() != arraylist_of_kurser[i + 1].get_name():
                antal_aktier += 1
                index.append(i)
        else:
            antal_aktier += 1
            index.append(i)
    for i in range(antal_aktier):
        if arraylist_of_fundamenta[i].get_name() == ''.join(arraylist_of_kurser[index[i]].get_name()):
            pstal.append([arraylist_of_fundamenta[i].get_name(), arraylist_of_fundamenta[i].get_pstal()])
    pstal = sorted(pstal, key=lambda x: x[1], reverse=True)
    for i in range(antal_aktier):
        print (" ".join(map(str, [pstal[i][0], pstal[i][1]])))
    # för att få en extra space efter att listan presenterats print

# ----------------------------- Hantering och inställningar av textfilerna ------------------------------------------ #

# Denna klass läser från fil.
# Varje metod läser från en separat fil. fundamenta.txt, kurser.txt samt omx.txt

# Finns en splitmetod som delar in innehållet i fundamentafilen till en array med 4 platser,
# som sedan läggs in i arrayListOfFundamenta

# arrayListOfFundamenta är alltså en lista av array där varje array har 4 platser som motsvarar
# aktienamn, soliditet, p/e-tal och p/s-tal.


class readFromFile:
    def lasFilOMX(self):
        arraylist_of_omx = []
        with open("omx.txt") as file_pointer:
        # file pointer (fp) är ett annat ord  för att hänvisa vart vi vill använda vår fil.
        # typ en struktur som håller information om filen
            # for line in file_pointer:
            content = file_pointer.readlines()[1:]

        content = [lines_on_the_list.strip().split("\t") for lines_on_the_list in content]
        #tar bort tabbar "whitespaces"
        #strip för så att onödiga whitespaces tas bort
        #split gör så att linjerna på listan delas upp med hjälp av \t
        #vilket gör så att det bildas en tab/en större mängd whitespace
        for item in content:
            arraylist_of_omx.append(Omx([item[0]], item[1]))

        return arraylist_of_omx

    def lasFilFUNDAMENTA(self):
        with open("fundamenta.txt") as file_pointer:
        # file pointer (fp) är ett annat ord  för att hänvisa vart vi vill använda vår fil.
        # typ en struktur som håller information om filen
            # for line in file_pointer:
            content = file_pointer.readlines()[1:]

        content = [lines_on_the_list.strip() for lines_on_the_list in content]
        #strip för så att onödiga whitespaces tas bort när informationshantering av datum, värde och namn hos txt filerna
        listFundamenta = self.split(content, 4)
        arraylistOfFundamenta = []
        for item in listFundamenta:
            arraylistOfFundamenta.append(Fundamenta(item[0], item[1], item[2], item[3]))
        # Delar listan till flera obj i en lista. Du kan infoga ett print(listFundamenta) kommando för att förstå

        return arraylistOfFundamenta

    #splitmetod som delar in innehållet i fundamentafilen till en array med 4 platser,
    def split(self, arr, size):
        arrs = []
        while len(arr) > size:
            pice = arr[:size]
            arrs.append(pice)
            arr = arr[size:]
        arrs.append(arr)

        return arrs

    def lasFilKurser(self):
        with open("kurser.txt") as file_pointer:
            # file pointer (fp) är ett annat ord  för att hänvisa vart vi vill använda vår fil.
            # typ en struktur som håller information om filen
            content = file_pointer.readlines()[1:]
            # for line in file_pointer:

        content = [lines_on_the_list.strip().split("\t") for lines_on_the_list in content]
        #tar bort tabbar "whitespaces"
        #strip för så att onödiga whitespaces tas bort
        #split gör så att linjerna på listan delas upp med hjälp av \t
        #vilket gör så att det bildas en tab/en större mängd whitespace
        arraylistOfKurser = []
        #Skapar en ny lista vid namn arraylistOfKurser
        name = ""
        #Skapar en variabel med inget innehåll för stunden
        for i in range(0, len(content)):
        #Mellan 0 till sista linjevärdet hos content
            if content[i].__len__() == 1:
            #Om content i det valda datumet är lika med 1
                name = content[i]
                #Så ska name varibeln vara lika med content som innehållet det valda datumet
            else:
                arraylistOfKurser.append(Kurser(name, content[i][0], content[i][1]))
                #Annars så ska arraylistOfKurser innehålla namn, content med i och 0 som parametrar och i och 1

        return arraylistOfKurser
        #Returnan för att användas i andra funktioner och klasser

# --------------------------------- Menyerna användaren ska skriva sig fram på -------------------------------------- #

# Loopar tills man valt nummer 4 som är avsluta
# Meny som tar 3 listor som inparametrar. Varje lista motsvarar en txt-fil.
# Väljer 1-4. Varje vad ropar på en ny metod (förutom val 4)


def meny(arraylist_of_fundamenta, arraylist_of_kurser, arraylist_of_omx):
    print("---Meny---\n")
    print("1. Fundamental analys\n")
    print("2. Teknisk analys\n")
    print("3. Rangordning av aktier med avseende pÂ dess betavärde\n")
    print("4. Avsluta\n")
    val = 0
    while val != 4:
        try:
            val = int(input("Vilket alternativ vill du välja? \n "))
            if val == 1:
                fundamentaAnalys(arraylist_of_fundamenta)
            elif val == 2:
                tekniskAnalys(arraylist_of_kurser, arraylist_of_omx, arraylist_of_fundamenta)
            elif val == 3:
                rangordning(arraylist_of_kurser, arraylist_of_fundamenta)
            elif val == 4:
                print("Tack och hej då.")
                exit()
            else:
                print('Det måste vara en siffra mellan 1-4')
        except ValueError:
            print('Fel siffra\n')


# ------------ Main som innehåller alla komandon vilket får vårt program att initieras med en sträng ---------------- #

# main metod som körs i början av programmet. Börjar med att läsa in filerna.
# skapar listor som är en lista av objekt, alltså av klasserna Fundamenta, Kurser samt Omx.


def main():
    arraylist_of_fundamenta = readFromFile().lasFilFUNDAMENTA()
    arraylist_of_kurser = readFromFile().lasFilKurser()
    arraylist_of_omx = readFromFile().lasFilOMX()
    meny(arraylist_of_fundamenta, arraylist_of_kurser, arraylist_of_omx)

# ------------------------------------ Kommandot som kör vårt program ----------------------------------------------- #
if __name__ == "__main__":
    main()
